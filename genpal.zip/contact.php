<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GenPal Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link href="style.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
        h1{
            color: black;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="row" align="center">
        <div class="logo">
        <img src="logo.png">
        <label class="platform">GenPal</label>
        </div>
            
    <ul class="main-nav">    
        <li><a href="login.php"> HOME </a></li>
        <li><a href="about.php"> ABOUT </a></li>
        <li class="active"><a href="contact.php"> CONTACT </a></li>
    </ul>    
        
</div>
    <div align="center">
        
    <div>
        <h1>Info</h1><b/>
        <h3>Aurnob: islamau@sheridancollege.ca</h3>
        <h3>Bobby: oshaugro@sheridancollege.ca</h3>
        <h3>Chirag: solankic@sheridancollege.ca</h3>
        <h3>Syed: ahmed47@sheridancollege.ca</h3>
        <h3>Roshan: georrosh@sheridancollege.ca</h3>
        </br></br>
        
    </div>
</div>
        
</body>
</html>